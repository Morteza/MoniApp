#include "ReportModel.h"

ReportModel::ReportModel()
{
}
