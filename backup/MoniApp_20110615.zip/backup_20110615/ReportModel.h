#ifndef REPORTMODEL_H
#define REPORTMODEL_H

class ReportModel
{
public:
	ReportModel();
	~ReportModel();
};

#endif // REPORTMODEL_H
